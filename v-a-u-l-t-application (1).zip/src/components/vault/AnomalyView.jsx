import React from "react";
import AnomalyCard from "./AnomalyCard";

export default function AnomalyView({ anomalies }) {
  return (
    <div className="px-5 pt-5 pb-6">
      <p className="font-mono text-[9px] tracking-[0.22em] text-white/30">
        ANOMALY RESOLUTION
      </p>
      <p className="mt-1.5 text-[19px] font-light tracking-wide text-white">
        Tactical Alerts
        <span className="ml-2 font-mono text-[13px] text-[#FFB300]/85">
          {anomalies.length}
        </span>
      </p>

      <div className="mt-6 space-y-3">
        {anomalies.length === 0 ? (
          <p className="rounded-xl border border-white/10 bg-white/[0.03] p-6 text-center font-mono text-[11px] tracking-[0.12em] text-white/30">
            NO ACTIVE ANOMALIES
          </p>
        ) : (
          anomalies.map((a) => <AnomalyCard key={a.id} anomaly={a} />)
        )}
      </div>
    </div>
  );
}