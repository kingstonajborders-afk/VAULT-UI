import React from "react";
import { motion } from "framer-motion";

export default function EnergyGauge({ value }) {
  const r = 46;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative h-[124px] w-[124px] shrink-0">
      <svg viewBox="0 0 110 110" className="h-full w-full -rotate-90">
        <circle cx="55" cy="55" r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="4" />
        <motion.circle
          cx="55"
          cy="55"
          r={r}
          fill="none"
          stroke="#00E5FF"
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c - (c * value) / 100 }}
          transition={{ duration: 1.1, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-mono text-2xl text-white">{value}%</span>
        <span className="font-mono text-[9px] tracking-[0.16em] text-white/35">CAPACITY</span>
      </div>
    </div>
  );
}