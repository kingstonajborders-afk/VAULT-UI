import React from "react";
import { Image } from "@/components/ui/image";

export default function IntellePulseLogo({ className = "h-7 w-7" }) {
  return (
    <Image
      src="https://media.base44.com/images/public/6a73750bc3fe0f331631c604/98b3db6e7_1000011066.png"
      alt="IntellePulse"
      fittingType="fit"
      className={className}
    />
  );
}