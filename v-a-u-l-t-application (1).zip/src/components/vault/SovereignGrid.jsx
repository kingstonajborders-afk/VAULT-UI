import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MapContainer, TileLayer, Marker } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import GridBackdrop from "./GridBackdrop";
import NodeCard from "./NodeCard";

const CVG_CENTER = [39.0488, -84.6678];

const buildIcon = (node) => {
  const color = node.priority === "low" ? "#FFB300" : "#00E5FF";
  return L.divIcon({
    className: "vault-marker",
    html: `
      <div class="relative flex items-center">
        <span class="relative flex h-3 w-3">
          <span class="absolute inline-flex h-full w-full animate-ping rounded-full opacity-60" style="background-color:${color}"></span>
          <span class="relative inline-flex h-3 w-3 rounded-full" style="background-color:${color};box-shadow:0 0 10px ${color}99"></span>
        </span>
        <span class="ml-3.5 whitespace-nowrap font-mono text-[9px] tracking-[0.1em] text-white/55">${node.id}</span>
      </div>`,
    iconSize: [12, 12],
    iconAnchor: [6, 6],
  });
};

export default function SovereignGrid({ nodes, filterNoise, onToggleFilter, onSelect }) {
  const visible = filterNoise ? nodes.filter((n) => n.priority !== "low") : nodes;

  return (
    <div className="relative min-h-[calc(100vh-8rem)]">
      <GridBackdrop />

      <div className="relative px-5 pt-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="font-mono text-[9px] tracking-[0.22em] text-white/30">
              SOVEREIGN GRID
            </p>
            <p className="mt-1.5 text-[19px] font-light tracking-wide text-white">
              Active Nodes
              <span className="ml-2 font-mono text-[13px] text-[#00E5FF]/80">
                {visible.length}
              </span>
            </p>
          </div>
          <button
            onClick={onToggleFilter}
            className="flex items-center gap-2.5 rounded-lg border border-white/10 bg-white/[0.04] px-3 py-2 backdrop-blur-xl"
          >
            <span className="font-mono text-[9px] tracking-[0.14em] text-white/50">
              FILTER NOISE
            </span>
            <span
              className={`relative h-4 w-8 rounded-full transition-colors ${
                filterNoise ? "bg-[#00E5FF]/35" : "bg-white/10"
              }`}
            >
              <motion.span
                animate={{ x: filterNoise ? 16 : 2 }}
                transition={{ type: "spring", stiffness: 500, damping: 32 }}
                className={`absolute top-0.5 h-3 w-3 rounded-full ${
                  filterNoise ? "bg-[#00E5FF]" : "bg-white/40"
                }`}
              />
            </span>
          </button>
        </div>

        <div className="relative mt-6 h-44 overflow-hidden rounded-xl border border-slate-800 shadow-[inset_0_0_24px_rgba(0,0,0,0.55)] isolate">
          <MapContainer
            center={CVG_CENTER}
            zoom={13}
            scrollWheelZoom={false}
            style={{ height: "100%", width: "100%", background: "#0B0F19" }}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; OpenStreetMap contributors'
              maxZoom={19}
              referrerPolicy="origin"
            />
            {visible.map((n) => (
              <Marker
                key={n.id}
                position={n.latLng}
                icon={buildIcon(n)}
                eventHandlers={{ click: () => onSelect(n) }}
              />
            ))}
          </MapContainer>
        </div>

        <div className="mt-5 space-y-2.5 pb-6">
          <AnimatePresence mode="popLayout">
            {visible.map((n) => (
              <NodeCard key={n.id} node={n} onSelect={onSelect} />
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}