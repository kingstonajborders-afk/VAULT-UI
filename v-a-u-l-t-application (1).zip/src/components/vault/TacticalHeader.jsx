import React from "react";
import IntellePulseLogo from "./IntellePulseLogo";

export default function TacticalHeader() {
  return (
    <header className="fixed top-0 inset-x-0 z-40 border-b border-white/10 bg-[#0B0F19]/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-3xl items-center justify-between px-5 py-3.5">
        <div className="flex items-center gap-3">
          <IntellePulseLogo className="h-8 w-8" />
          <span className="font-mono text-[11px] tracking-[0.14em] text-[#00E5FF]/80">
            V.A.U.L.T. ACTIVE
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          <span className="font-mono text-[9px] tracking-[0.16em] text-emerald-300/70">
            SECURE
          </span>
        </div>
      </div>
    </header>
  );
}