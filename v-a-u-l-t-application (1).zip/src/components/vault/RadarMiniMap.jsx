import React from "react";
import { motion } from "framer-motion";

export default function RadarMiniMap({ mgrs }) {
  return (
    <div className="relative h-[120px] w-[120px] overflow-hidden rounded-lg border border-slate-800 bg-[#0B0F19] shadow-[inset_0_0_18px_rgba(0,0,0,0.65)]">
      {/* Grid lines */}
      <div
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,229,255,0.14) 1px, transparent 1px), linear-gradient(90deg, rgba(0,229,255,0.14) 1px, transparent 1px)",
          backgroundSize: "15px 15px",
        }}
      />
      {/* Range rings */}
      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 120 120">
        <circle cx="60" cy="60" r="22" fill="none" stroke="rgba(0,229,255,0.22)" strokeWidth="0.75" />
        <circle cx="60" cy="60" r="44" fill="none" stroke="rgba(0,229,255,0.16)" strokeWidth="0.75" />
        <circle cx="60" cy="60" r="58" fill="none" stroke="rgba(0,229,255,0.10)" strokeWidth="0.75" />
        {/* Crosshair */}
        <line x1="60" y1="6" x2="60" y2="114" stroke="rgba(0,229,255,0.30)" strokeWidth="0.6" />
        <line x1="6" y1="60" x2="114" y2="60" stroke="rgba(0,229,255,0.30)" strokeWidth="0.6" />
        {/* Center node */}
        <circle cx="60" cy="60" r="2.5" fill="#00E5FF" />
        <circle cx="60" cy="60" r="6" fill="none" stroke="#00E5FF" strokeWidth="0.8" />
      </svg>
      {/* Sweep */}
      <motion.div
        initial={{ rotate: 0 }}
        animate={{ rotate: 360 }}
        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        className="absolute inset-0"
        style={{
          background:
            "conic-gradient(from 0deg, rgba(0,229,255,0.28) 0deg, rgba(0,229,255,0) 60deg)",
        }}
      />
      {/* Label */}
      <p className="absolute bottom-1 left-1.5 font-mono text-[7px] tracking-[0.14em] text-[#00E5FF]/55">
        100M PERIMETER
      </p>
      <p className="absolute right-1.5 top-1 font-mono text-[7px] tracking-[0.14em] text-white/35">
        {mgrs}
      </p>
    </div>
  );
}