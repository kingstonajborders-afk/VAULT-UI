import React from "react";
import { motion } from "framer-motion";
import { Activity } from "lucide-react";

export default function TelemetryView({ nodes, onSelect }) {
  return (
    <div className="px-5 pt-5 pb-6">
      <p className="font-mono text-[9px] tracking-[0.22em] text-white/30">TELEMETRY</p>
      <p className="mt-1.5 text-[19px] font-light tracking-wide text-white">Asset Streams</p>

      <div className="mt-6 space-y-3">
        {nodes.map((n, i) => (
          <motion.button
            key={n.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            whileTap={{ scale: 0.985 }}
            onClick={() => onSelect(n)}
            className="w-full rounded-xl border border-white/10 bg-white/[0.04] p-4 text-left backdrop-blur-xl transition-colors hover:border-[#00E5FF]/35"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[12px] tracking-[0.12em] text-white/90">
                {n.id}
              </span>
              <Activity className="h-3.5 w-3.5 text-[#00E5FF]/70" strokeWidth={1.8} />
            </div>
            <p className="mt-1 font-mono text-[10px] tracking-[0.1em] text-[#00E5FF]/45">
              {n.status} · {n.sector} — {n.mgrs}
            </p>
            <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/10">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${n.capacity}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="h-full rounded-full bg-[#00E5FF]"
              />
            </div>
            <div className="mt-2.5 flex justify-between font-mono text-[10px] tracking-[0.1em] text-white/35">
              <span>INTAKE {n.solarIntake}%</span>
              <span>DRAIN {n.drain}%</span>
              <span className="text-white/60">CAP {n.capacity}%</span>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}