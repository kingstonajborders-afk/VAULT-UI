import React from "react";
import { motion } from "framer-motion";
import { Navigation, ChevronRight } from "lucide-react";

export default function NodeCard({ node, onSelect }) {
  const low = node.priority === "low";
  const accent = low ? "#FFB300" : "#00E5FF";
  return (
    <motion.button
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -24, scale: 0.97 }}
      transition={{ type: "spring", stiffness: 320, damping: 30 }}
      whileTap={{ scale: 0.985 }}
      onClick={() => onSelect(node)}
      className="w-full rounded-xl border border-white/10 bg-white/[0.045] px-4 py-3.5 text-left backdrop-blur-xl transition-colors hover:border-white/20"
    >
      <div className="flex items-center gap-3.5">
        <span
          className="flex h-9 w-9 items-center justify-center rounded-lg border"
          style={{ borderColor: `${accent}55`, backgroundColor: `${accent}12` }}
        >
          <Navigation className="h-4 w-4" style={{ color: accent }} strokeWidth={1.7} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-mono text-[13px] tracking-[0.1em] text-white/90">{node.id}</p>
          <p className="mt-0.5 text-[11px] tracking-wide" style={{ color: `${accent}b0` }}>
            {node.status} <span className="text-white/25">· {node.sector}</span>
          </p>
          <p className="mt-1 font-mono text-[10px] tracking-[0.1em] text-[#00E5FF]/45">
            {node.mgrs}
          </p>
        </div>
        <div className="text-right">
          <p className="font-mono text-[13px] text-white/80">{node.capacity}%</p>
          <p className="font-mono text-[9px] tracking-[0.14em] text-white/25">CAP</p>
        </div>
        <ChevronRight className="h-4 w-4 text-white/20" strokeWidth={1.6} />
      </div>
    </motion.button>
  );
}