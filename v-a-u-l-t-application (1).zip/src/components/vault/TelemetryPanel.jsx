import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Sun, BatteryCharging, ShieldCheck, Cpu, Timer, Thermometer, Wind, Fuel } from "lucide-react";
import EnergyGauge from "./EnergyGauge";
import RadarMiniMap from "./RadarMiniMap";

export default function TelemetryPanel({ node, onClose }) {
  return (
    <AnimatePresence>
      {node && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[1000] bg-black/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 340, damping: 34 }}
            className="fixed bottom-0 inset-x-0 z-[1000] mx-auto max-h-[88vh] max-w-3xl overflow-y-auto rounded-t-2xl border-t border-white/15 bg-[#0B0F19]/85 backdrop-blur-2xl"
          >
            <div className="sticky top-0 flex items-start justify-between gap-3 border-b border-white/10 bg-[#0B0F19]/70 px-5 py-4 backdrop-blur-xl">
              <div>
                <p className="font-mono text-[9px] tracking-[0.2em] text-white/30">
                  ASSET TELEMETRY
                </p>
                <p className="mt-1 font-mono text-[15px] tracking-[0.12em] text-white">
                  {node.id}
                </p>
              </div>
              <RadarMiniMap mgrs={node.mgrs} />
              <button
                onClick={onClose}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-white/10 text-white/50 transition-colors hover:text-white"
              >
                <X className="h-4 w-4" strokeWidth={1.7} />
              </button>
            </div>

            <div className="space-y-4 px-5 py-5 pb-10">
              <section className="rounded-xl border border-white/10 bg-white/[0.04] p-4">
                <p className="font-mono text-[9px] tracking-[0.2em] text-[#00E5FF]/70">
                  ENERGY LOGIC
                </p>
                <div className="mt-3 flex items-center gap-5">
                  <EnergyGauge value={node.capacity} />
                  <div className="flex-1 space-y-3">
                    <div className="flex items-center gap-2.5">
                      <Sun className="h-4 w-4 text-[#FFB300]" strokeWidth={1.7} />
                      <span className="flex-1 text-[11px] tracking-wide text-white/50">
                        Solar Intake
                      </span>
                      <span className="font-mono text-[13px] text-white/85">
                        {node.solarIntake}%
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <BatteryCharging className="h-4 w-4 text-[#00E5FF]" strokeWidth={1.7} />
                      <span className="flex-1 text-[11px] tracking-wide text-white/50">
                        Drain
                      </span>
                      <span className="font-mono text-[13px] text-white/85">{node.drain}%</span>
                    </div>
                    <div className="h-px bg-white/10" />
                    <p className="font-mono text-[10px] tracking-[0.1em] text-emerald-300/70">
                      NET +{node.solarIntake - node.drain}% / CYCLE
                    </p>
                    <div className="flex items-center gap-2.5 pt-0.5">
                      <Timer
                        className="h-4 w-4"
                        strokeWidth={1.7}
                        style={{ color: node.dwellExceeded ? "#FFB300" : "#00E5FF" }}
                      />
                      <span className="flex-1 text-[11px] tracking-wide text-white/50">
                        Dwell Time
                      </span>
                      <span
                        className={`font-mono text-[12px] tracking-[0.08em] ${
                          node.dwellExceeded
                            ? "text-[#FFB300]"
                            : "text-white/85"
                        }`}
                      >
                        {node.dwellTime}
                      </span>
                    </div>
                    {node.dwellExceeded && (
                      <p className="font-mono text-[9px] tracking-[0.14em] text-[#FFB300]/70">
                        ⚠ DWELL EXCEEDS STANDARD PARAMETERS
                      </p>
                    )}
                    <div className="flex items-center gap-2.5 pt-0.5">
                      <Cpu className="h-4 w-4 text-[#00E5FF]/70" strokeWidth={1.7} />
                      <span className="flex-1 text-[11px] tracking-wide text-white/50">
                        Core Temp
                      </span>
                      <span className="font-mono text-[12px] tracking-[0.08em] text-white/85">
                        {node.coreTemp}
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <Fuel className="h-4 w-4 text-[#00E5FF]/70" strokeWidth={1.7} />
                      <span className="flex-1 text-[11px] tracking-wide text-white/50">
                        Reserve Fuel
                      </span>
                      <span className="font-mono text-[12px] tracking-[0.08em] text-white/85">
                        {node.reserveFuel}
                      </span>
                    </div>
                  </div>
                </div>
              </section>

              <section className="rounded-xl border border-white/10 bg-white/[0.04] p-4">
                <p className="font-mono text-[9px] tracking-[0.2em] text-[#00E5FF]/70">
                  LOCAL ATMOSPHERICS
                </p>
                <div className="mt-3 grid grid-cols-3 gap-3">
                  <div className="flex flex-col items-center gap-1.5 rounded-lg border border-white/10 bg-black/30 px-2 py-3 text-center">
                    <Thermometer className="h-4 w-4 text-cyan-500/70" strokeWidth={1.7} />
                    <span className="font-mono text-[8px] tracking-[0.14em] text-white/35">
                      TEMP
                    </span>
                    <span className="font-mono text-[12px] text-white/85">
                      {node.atmospherics.temp}
                    </span>
                  </div>
                  <div className="flex flex-col items-center gap-1.5 rounded-lg border border-white/10 bg-black/30 px-2 py-3 text-center">
                    <Wind className="h-4 w-4 text-cyan-500/70" strokeWidth={1.7} />
                    <span className="font-mono text-[8px] tracking-[0.14em] text-white/35">
                      WIND
                    </span>
                    <span className="font-mono text-[12px] text-white/85">
                      {node.atmospherics.wind}
                    </span>
                  </div>
                  <div className="flex flex-col items-center gap-1.5 rounded-lg border border-white/10 bg-black/30 px-2 py-3 text-center">
                    <Sun className="h-4 w-4 text-cyan-500/70" strokeWidth={1.7} />
                    <span className="font-mono text-[8px] tracking-[0.14em] text-white/35">
                      COND
                    </span>
                    <span className="font-mono text-[10px] leading-tight text-white/85">
                      {node.atmospherics.condition}
                    </span>
                  </div>
                </div>
              </section>

              <section className="rounded-xl border border-[#00E5FF]/25 bg-[#00E5FF]/[0.03] p-4">
                <div className="flex items-center gap-2">
                  <Cpu className="h-3.5 w-3.5 text-[#00E5FF]" strokeWidth={1.8} />
                  <p className="font-mono text-[9px] tracking-[0.2em] text-[#00E5FF]/70">
                    A.S.T.R.A. ROUTING
                  </p>
                </div>
                <div className="mt-3 rounded-lg border border-white/10 bg-black/50 p-3.5">
                  <p className="font-mono text-[12px] leading-relaxed text-[#00E5FF]/90">
                    &gt; {node.astra}
                    <span className="ml-1 inline-block h-3.5 w-1.5 translate-y-0.5 animate-pulse bg-[#00E5FF]/80" />
                  </p>
                </div>
              </section>

              <section className="flex items-center gap-3 rounded-xl border border-emerald-400/35 bg-emerald-400/[0.05] p-4">
                <span className="flex h-9 w-9 items-center justify-center rounded-full border border-emerald-400/50">
                  <ShieldCheck className="h-4 w-4 text-emerald-400" strokeWidth={1.8} />
                </span>
                <div>
                  <p className="font-mono text-[9px] tracking-[0.2em] text-white/30">
                    PAYLOAD STATUS
                  </p>
                  <p className="mt-1 font-mono text-[11px] tracking-[0.1em] text-emerald-300/90">
                    {node.payload}
                  </p>
                </div>
              </section>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}