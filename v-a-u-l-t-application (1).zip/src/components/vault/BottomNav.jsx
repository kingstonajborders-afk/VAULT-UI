import React from "react";
import { motion } from "framer-motion";
import { LayoutGrid, Activity, AlertTriangle } from "lucide-react";

const TABS = [
  { key: "grid", label: "GRID", Icon: LayoutGrid },
  { key: "telemetry", label: "TELEMETRY", Icon: Activity },
  { key: "anomalies", label: "ANOMALIES", Icon: AlertTriangle },
];

export default function BottomNav({ active, onChange, anomalyCount = 0 }) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 border-t border-white/10 bg-[#0B0F19]/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-3xl items-stretch justify-around px-4 pb-[env(safe-area-inset-bottom)]">
        {TABS.map(({ key, label, Icon }) => {
          const isActive = active === key;
          return (
            <button
              key={key}
              onClick={() => onChange(key)}
              className={`relative m-1.5 flex flex-1 flex-col items-center gap-1.5 rounded-lg border border-t-white/10 border-l-white/10 border-b-white/5 border-r-white/5 py-3 transition-colors ${
                isActive
                  ? "border-cyan-400 bg-cyan-500/10 text-cyan-400 shadow-[0_0_15px_rgba(0,229,255,0.5)]"
                  : "text-white/35"
              }`}
            >
              <span className="relative">
                <Icon
                  className={`h-[19px] w-[19px] transition-colors ${
                    isActive ? "text-cyan-400" : "text-white/35"
                  }`}
                  strokeWidth={1.6}
                />
                {key === "anomalies" && anomalyCount > 0 && (
                  <span className="absolute -right-2 -top-1.5 h-1.5 w-1.5 rounded-full bg-[#FFB300]" />
                )}
              </span>
              <span
                className={`font-mono text-[9px] tracking-[0.16em] transition-colors ${
                  isActive ? "text-cyan-400" : "text-white/30"
                }`}
              >
                {label}
              </span>
              {isActive && (
                <motion.span
                  layoutId="nav-underline"
                  className="absolute top-0 h-[2px] w-8 rounded-full bg-cyan-400"
                  transition={{ type: "spring", stiffness: 500, damping: 34 }}
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}