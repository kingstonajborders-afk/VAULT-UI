import React from "react";

export default function GridBackdrop() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-[#0B0F19]" />
      {/* Schematic geo-grid — muted dark-slate vector lines */}
      <div
        className="absolute inset-0 opacity-[0.28]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(148,163,184,0.10) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.10) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />
      <div
        className="absolute inset-0 opacity-[0.18]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(148,163,184,0.14) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.14) 1px, transparent 1px)",
          backgroundSize: "128px 128px",
        }}
      />
      <svg className="absolute inset-0 h-full w-full" preserveAspectRatio="none">
        {/* Corridor vectors */}
        <path
          d="M-20,120 C120,60 200,220 360,150 C480,95 560,210 720,160"
          fill="none"
          stroke="rgba(148,163,184,0.22)"
          strokeWidth="1"
        />
        <path
          d="M-20,320 C100,300 180,380 300,340 C440,294 520,400 720,350"
          fill="none"
          stroke="rgba(148,163,184,0.18)"
          strokeWidth="1"
        />
        <path
          d="M-20,520 C140,470 260,600 420,540 C540,494 640,580 760,530"
          fill="none"
          stroke="rgba(148,163,184,0.16)"
          strokeWidth="1"
        />
        {/* Range rings */}
        <circle cx="30%" cy="36%" r="70" fill="none" stroke="rgba(148,163,184,0.12)" />
        <circle cx="30%" cy="36%" r="130" fill="none" stroke="rgba(148,163,184,0.08)" />
      </svg>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_30%,rgba(26,32,44,0.55),rgba(11,15,25,0.95))]" />
    </div>
  );
}