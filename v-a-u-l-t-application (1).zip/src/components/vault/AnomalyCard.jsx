import React, { useState } from "react";
import { motion } from "framer-motion";
import { AlertTriangle, GitBranch, PauseOctagon, Check } from "lucide-react";
import AnomalyMiniMap from "./AnomalyMiniMap";

export default function AnomalyCard({ anomaly }) {
  const [resolution, setResolution] = useState(null);

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 28 }}
      className="rounded-xl border border-[#FFB300]/45 bg-[#FFB300]/[0.05] p-4 backdrop-blur-xl"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-[#FFB300]" strokeWidth={1.8} />
          <span className="font-mono text-[11px] tracking-[0.14em] text-[#FFB300]">
            {anomaly.severity}
          </span>
        </div>
        <span className="font-mono text-[10px] tracking-[0.12em] text-white/30">
          {anomaly.timestamp}
        </span>
      </div>

      <p className="mt-3 font-mono text-[10px] tracking-[0.14em] text-white/35">
        {anomaly.id} · {anomaly.node} · {anomaly.grid}
      </p>

      <p className="mt-3 font-mono text-[9px] tracking-[0.18em] text-white/30">
        INCIDENT RECONSTRUCTION
      </p>
      <p className="mt-1.5 text-[13px] leading-relaxed text-white/75">
        {anomaly.reconstruction}
      </p>

      <AnomalyMiniMap />

      {resolution ? (
        <div className="mt-4 flex items-center gap-2 rounded-lg border border-emerald-400/40 bg-emerald-400/[0.07] px-3.5 py-3">
          <Check className="h-4 w-4 text-emerald-400" strokeWidth={2} />
          <span className="font-mono text-[11px] tracking-[0.1em] text-emerald-300/90">
            {resolution}
          </span>
        </div>
      ) : (
        <div className="mt-4 space-y-2.5">
          <motion.button
            whileTap={{ scale: 0.97 }}
            whileHover={{ y: -1 }}
            onClick={() => setResolution("REROUTE EXECUTED · SECONDARY GRID")}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-b-2 border-r-2 border-t-white/10 border-l-white/10 border-b-[#00E5FF]/70 border-r-[#00E5FF]/70 bg-[#00E5FF]/[0.06] py-3 font-mono text-[11px] tracking-[0.12em] text-[#00E5FF] transition-colors hover:bg-[#00E5FF]/[0.14] active:bg-cyan-500/30 active:shadow-[0_0_20px_rgba(0,229,255,0.8)] active:border-cyan-400"
          >
            <GitBranch className="h-3.5 w-3.5" strokeWidth={1.8} />
            EXECUTE REROUTE VIA SECONDARY GRID
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.97 }}
            whileHover={{ y: -1 }}
            onClick={() => setResolution("STANDBY INITIATED · ASSET HALTED")}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-b-2 border-r-2 border-t-white/10 border-l-white/10 border-b-[#FFB300]/70 border-r-[#FFB300]/70 bg-[#FFB300]/[0.06] py-3 font-mono text-[11px] tracking-[0.12em] text-[#FFB300] transition-colors hover:bg-[#FFB300]/[0.14] active:bg-cyan-500/30 active:shadow-[0_0_20px_rgba(0,229,255,0.8)] active:border-cyan-400"
          >
            <PauseOctagon className="h-3.5 w-3.5" strokeWidth={1.8} />
            HALT &amp; INITIATE STANDBY
          </motion.button>
        </div>
      )}
    </motion.div>
  );
}