import React from "react";
import { MapContainer, TileLayer, Circle, CircleMarker } from "react-leaflet";

const INCIDENT = [39.035, -84.6555];

export default function AnomalyMiniMap() {
  return (
    <div className="mt-3 h-[150px] overflow-hidden rounded-lg border border-slate-800 shadow-[inset_0_0_24px_rgba(0,0,0,0.55)] isolate">
      <MapContainer
        center={INCIDENT}
        zoom={14}
        zoomControl={false}
        attributionControl={false}
        style={{ height: "100%", width: "100%" }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; OpenStreetMap contributors'
          referrerPolicy="origin"
        />
        <Circle
          center={INCIDENT}
          radius={420}
          pathOptions={{
            color: "#FFB300",
            fillColor: "#FFB300",
            fillOpacity: 0.12,
            weight: 1.5,
          }}
        />
        <CircleMarker
          center={INCIDENT}
          radius={6}
          pathOptions={{
            color: "#FFB300",
            fillColor: "#FFB300",
            fillOpacity: 0.9,
            weight: 2,
          }}
        />
      </MapContainer>
    </div>
  );
}