import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import TacticalHeader from "@/components/vault/TacticalHeader";
import BottomNav from "@/components/vault/BottomNav";
import SovereignGrid from "@/components/vault/SovereignGrid";
import TelemetryView from "@/components/vault/TelemetryView";
import AnomalyView from "@/components/vault/AnomalyView";
import TelemetryPanel from "@/components/vault/TelemetryPanel";
import { NODES, ANOMALIES } from "@/lib/vaultMockData";

export default function Terminal() {
  const [tab, setTab] = useState("grid");
  const [filterNoise, setFilterNoise] = useState(false);
  const [selected, setSelected] = useState(null);

  return (
    <div className="min-h-screen bg-[#0B0F19] text-white">
      <TacticalHeader />

      <main className="mx-auto max-w-3xl pb-24 pt-[58px]">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
          >
            {tab === "grid" && (
              <SovereignGrid
                nodes={NODES}
                filterNoise={filterNoise}
                onToggleFilter={() => setFilterNoise((v) => !v)}
                onSelect={setSelected}
              />
            )}
            {tab === "telemetry" && <TelemetryView nodes={NODES} onSelect={setSelected} />}
            {tab === "anomalies" && <AnomalyView anomalies={ANOMALIES} />}
          </motion.div>
        </AnimatePresence>
      </main>

      <TelemetryPanel node={selected} onClose={() => setSelected(null)} />
      <BottomNav active={tab} onChange={setTab} anomalyCount={ANOMALIES.length} />
    </div>
  );
}